package com.example.hitemamovie.data.repository

import com.example.hitemamovie.api.TmdbApi
import com.example.hitemamovie.data.model.MovieData

class MovieRepository(private val tmdbApi: TmdbApi) {
    suspend fun getPopularMovies(): List<MovieData> {
        val response = tmdbApi.getPopularMovies()
        return if (response.isSuccessful) {
            response.body()?.results ?: emptyList()
        } else {
            emptyList()
        }
    }
}